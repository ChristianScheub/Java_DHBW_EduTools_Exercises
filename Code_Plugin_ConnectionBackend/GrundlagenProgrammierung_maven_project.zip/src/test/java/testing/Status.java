package testing;

public enum Status {
    PASSED, ABORTED, FAILED, DISABLED;
}