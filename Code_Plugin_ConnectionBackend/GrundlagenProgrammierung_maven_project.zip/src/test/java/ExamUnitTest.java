import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Timeout.ThreadMode;
import org.junit.jupiter.api.extension.ExtendWith;

import testing.UniGraderTestResultExtension;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@ExtendWith(UniGraderTestResultExtension.class)
class ExamUnitTest
{
	private static final int DEFAULT_TIMEOUT = 30;

	//private static final String CLASS_TEMPLATE = "de.dhbw.assignments.exam.impl.%s";
	private static final String CLASS_TEMPLATE = "de.dhbw.assignments.exam.solution.%s";


	@Test
	public void test_01_Berechnung1() {

		int result = Factorial.computeFactorial(5);
		assertEquals(result, 120);
	}
	@Test
	@Timeout(value = DEFAULT_TIMEOUT, unit = TimeUnit.SECONDS, threadMode = ThreadMode.SEPARATE_THREAD)
	public void test_01_Berechnung2() {

		int result = Factorial.computeFactorial(0);
		assertEquals(result, 1);
	}
	@Test
	public void test_01_Berechnung3() {

		int result = Factorial.computeFactorial(-5);
		assertEquals(result, -1);
	}

	@Test
	public void test_01_minimun1() {

		double[] input = new double[]{0.0, 1.0, -5.0};
		double result = Minimum.computeMinumum(input);
		assertEquals(result, -5.0, 0.0);
	}
	@Test
	public void test_01_minimun2() {
		double[] input = new double[]{};
		double result = Minimum.computeMinumum(input);
		assertEquals(result, Double.NaN, 0.0);
	}
	@Test
	public void test_01_Berechnung4() {
		double[] input = null;
		double result = Minimum.computeMinumum(input);
		assertEquals(result, Double.NaN, 0.0);
	}
}
