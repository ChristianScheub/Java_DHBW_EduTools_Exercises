package de.hans.wif.lectures.prog1; // you may ignore this line but keep it and don't delete it!

public class HalloAnsbach{

    public static void main(String[] args) {
        System.out.println("Hallo, Ansbach!");
    }

}